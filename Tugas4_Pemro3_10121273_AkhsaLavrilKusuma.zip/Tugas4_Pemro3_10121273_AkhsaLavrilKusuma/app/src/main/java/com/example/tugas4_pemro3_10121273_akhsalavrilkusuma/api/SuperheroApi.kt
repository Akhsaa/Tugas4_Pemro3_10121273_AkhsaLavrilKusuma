package com.example.tugas4_pemro3_10121273_akhsalavrilkusuma.api

import com.example.tugas4_pemro3_10121273_akhsalavrilkusuma.model.Superhero
import retrofit2.Call
import retrofit2.http.GET

interface SuperheroApi {
    @GET("30")
    fun getSuperhero(): Call<Superhero>
}